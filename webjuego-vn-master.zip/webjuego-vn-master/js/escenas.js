var escenas =	[
					{
						'ES':'<strong>Wikipe-tan:</strong> ¡Hola! Bienvenido a Webjuego VN. Este juego esta hecho en HTML+CSS+JS y tiene licencia GPLv2.',
						'EN':'<strong>Wikipe-tan:</strong> ¡Hi! Welcome to Webgame VN. This game is made in HTML+CSS+JS and have GPLv2 licence.',
						'bg':'convenienceStore.jpg',
						'char1':'wikipetan.png',
						'char2':'',
						'char3':'',
					},
					{
						'ES':'<strong>Commons-tan:</strong> El sistema del juego es bastantes sencillo y permite una fácil modificación mediante un archivo llamado escenas.js.',
						'EN':'<strong>Commons-tan:</strong> The game system is really simple and allow an easy modification through the file escenas.js.',
						'bg':'convenienceStore.jpg',
						'char1':'commonstan.png',
						'char2':'wikipetan.png',
						'char3':'',
					},
					{
						'ES':'<strong>Quote-tan:</strong> Este es el último diálogo del juego. Si sigues avanzando el juego te muestra un mensaje diciendote que no hay más escenas.',
						'EN':'<strong>Quote-tan:</strong> This is the last dialogue in the game. If you keep moving the game displays a message telling you that there is not more scenes.',
						'bg':'convenienceStore.jpg',
						'char1':'commonstan.png',
						'char2':'wikipetan.png',
						'char3':'quotetan.png',
					}
				];